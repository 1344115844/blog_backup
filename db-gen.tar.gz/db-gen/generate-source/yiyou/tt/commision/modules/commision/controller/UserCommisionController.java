package yiyou.tt.commision.modules.commision.controller;

import com.lingz.component.datatable.BootstrapTable;
import java.util.List;
import java.util.Map;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.util.Assert;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import yiyou.tt.commision.modules.commision.model.UserCommision;
import yiyou.tt.commision.modules.commision.service.UserCommisionService;

@Controller
@RequestMapping("userCommision")
public class UserCommisionController {
    @Autowired
    private UserCommisionService userCommisionService;

    @RequestMapping("/index")
    public String index() {
        return "userCommision/index";
    }

    @RequestMapping("/getList")
    @ResponseBody
    public BootstrapTable getList(UserCommision userCommision, Order order, int offset, int limit) {
        int total = userCommisionService.selectTotal(userCommision);
        List<UserCommision> list = null;
        if(total > 0) {
            list = userCommisionService.selectList(userCommision, order, offset, limit);
        }
        
        return ResponseHelper.BootstrapTable(total, list);
    }

    @RequestMapping("/update")
    @ResponseBody
    public Map update(UserCommision userCommision) {
        
        if (userCommisionService.updateByPrimaryKeySelective(userCommision) < 1 ) {
            return ResponseHelper.buildErrorResult("更新失败");
        }
        
        return ResponseHelper.buildSuccessResult();
    }

    @RequestMapping("/save")
    @ResponseBody
    public Map save(UserCommision userCommision) {
        if (userCommisionService.insertSelective(userCommision) < 1 ) {
            return ResponseHelper.buildErrorResult(" 添加失败 ");
        }
        
        return ResponseHelper.buildSuccessResult();
    }

    @RequestMapping("/detail")
    public String detail(Long userId, Integer appId, Model model) {
        Assert.notNull(userId, "userId不能为空");
        Assert.notNull(appId, "appId不能为空");
        
        UserCommision userCommision = userCommisionService.selectByPrimaryKey(userId,appId);
        
        Assert.notNull(userCommision, "对象不存在");
        
        model.addAttribute("userCommision", userCommision);
        return "userCommision/detail";
    }

    @RequestMapping("/delete")
    @ResponseBody
    public Map delete(Long userId, Integer appId) {
        Assert.notNull(userId, "userId不能为空");
        Assert.notNull(appId, "appId不能为空");
        
        if (userCommisionService.deleteByPrimaryKey(userId,appId) < 1) {
            return ResponseHelper.buildErrorResult("删除失败");
        }
        
        return ResponseHelper.buildSuccessResult("删除成功");
    }
}