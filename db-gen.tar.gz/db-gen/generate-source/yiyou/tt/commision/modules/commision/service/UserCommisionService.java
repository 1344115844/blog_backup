package yiyou.tt.commision.modules.commision.service;

import com.lingz.component.db.Order;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.util.Assert;
import org.springframework.util.CollectionUtils;
import yiyou.tt.commision.modules.commision.mapper.UserCommisionMapper;
import yiyou.tt.commision.modules.commision.model.UserCommision;

@Service
public class UserCommisionService {
    @Autowired
    private UserCommisionMapper userCommisionMapper;

    public int deleteByPrimaryKey(Long userId, Integer appId) {
        Assert.notNull(userId,"userId不能为空");
        Assert.notNull(appId,"appId不能为空");
        return userCommisionMapper.deleteByPrimaryKey(userId,appId);
    }

    public int insert(UserCommision record) {
        Assert.notNull(record, "查询对象不能为空");
        return userCommisionMapper.insert(record);
    }

    public int insertSelective(UserCommision record) {
        Assert.notNull(record, "查询对象不能为空");
        return userCommisionMapper.insertSelective(record);
    }

    public UserCommision selectByPrimaryKey(Long userId, Integer appId) {
        Assert.notNull(userId, "userId不能为空");
        Assert.notNull(appId, "appId不能为空");
        return userCommisionMapper.selectByPrimaryKey(userId,appId);
    }

    public int updateByPrimaryKeySelective(UserCommision record) {
        Assert.notNull(record, "查询对象不能为空");
        return userCommisionMapper.updateByPrimaryKeySelective(record);
    }

    public int selectTotal(UserCommision record) {
        Assert.notNull(record, "查询对象不能为空");
        return userCommisionMapper.selectTotal(record);
    }

    public List<UserCommision> selectList(UserCommision record, Order order, int offset, int count) {
        Assert.notNull(record, "查询对象不能为空");
        return userCommisionMapper.selectList(record, order, offset, count);
    }

    public UserCommision selectOne(UserCommision record, Order order) {
        Assert.notNull(record, "查询对象不能为空");
        List<UserCommision> list = selectList(record, order, 0, 1);
        return CollectionUtils.isEmpty(list) ? null : list.get(0);
    }
}