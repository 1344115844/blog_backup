package yiyou.tt.commision.modules.commision.model;

import java.io.Serializable;
import java.util.Date;

public class UserCommision implements Serializable {
    /**
     *  用户ID
     */
    private Long userId;

    /**
     *  业务id,对应app_config.app_id
     */
    private Integer appId;

    /**
     *  佣金历史总额，货币单位(RMB)
     */
    private Double total;

    /**
     *  佣金余额，货币单位(RMB)
     */
    private Double balance;

    /**
     *  状态(1,可提现;2,禁止提现)
     */
    private Byte status;

    /**
     *  修改时间
     */
    private Date modifyTime;

    /**
     *  创建时间
     */
    private Date createTime;

    /**
     *  是否被逻辑删除(1,已经删除;0,未删除)
     */
    private Boolean deleted;

    /**
     *  账户类型,0:对私;1:对公
     */
    private Integer type;

    private static final long serialVersionUID = 1L;

    public Long getUserId() {
        return userId;
    }

    public void setUserId(Long userId) {
        this.userId = userId;
    }

    public Integer getAppId() {
        return appId;
    }

    public void setAppId(Integer appId) {
        this.appId = appId;
    }

    public Double getTotal() {
        return total;
    }

    public void setTotal(Double total) {
        this.total = total;
    }

    public Double getBalance() {
        return balance;
    }

    public void setBalance(Double balance) {
        this.balance = balance;
    }

    public Byte getStatus() {
        return status;
    }

    public void setStatus(Byte status) {
        this.status = status;
    }

    public Date getModifyTime() {
        return modifyTime;
    }

    public void setModifyTime(Date modifyTime) {
        this.modifyTime = modifyTime;
    }

    public Date getCreateTime() {
        return createTime;
    }

    public void setCreateTime(Date createTime) {
        this.createTime = createTime;
    }

    public Boolean getDeleted() {
        return deleted;
    }

    public void setDeleted(Boolean deleted) {
        this.deleted = deleted;
    }

    public Integer getType() {
        return type;
    }

    public void setType(Integer type) {
        this.type = type;
    }
}