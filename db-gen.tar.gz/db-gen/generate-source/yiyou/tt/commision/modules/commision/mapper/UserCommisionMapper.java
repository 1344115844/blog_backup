package yiyou.tt.commision.modules.commision.mapper;

import com.lingz.component.db;
import java.util.List;
import org.apache.ibatis.annotations.Param;
import yiyou.tt.commision.modules.commision.model.UserCommision;

public interface UserCommisionMapper {
    int deleteByPrimaryKey(@Param("userId") Long userId, @Param("appId") Integer appId);

    int insert(UserCommision record);

    int insertSelective(UserCommision record);

    UserCommision selectByPrimaryKey(@Param("userId") Long userId, @Param("appId") Integer appId);

    int updateByPrimaryKeySelective(UserCommision record);

    int updateByPrimaryKey(UserCommision record);

    int selectTotal(@Param("record") UserCommision record);

    List<UserCommision> selectList(@Param("record") UserCommision record, @Param("order") Order order, @Param("offset") int offset, @Param("count") int count);
}