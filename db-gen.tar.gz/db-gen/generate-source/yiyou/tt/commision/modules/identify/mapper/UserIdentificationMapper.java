package yiyou.tt.commision.modules.identify.mapper;

import com.lingz.component.db;
import java.util.List;
import org.apache.ibatis.annotations.Param;
import yiyou.tt.commision.modules.identify.model.UserIdentification;

public interface UserIdentificationMapper {
    int deleteByPrimaryKey(Long userId);

    int insert(UserIdentification record);

    int insertSelective(UserIdentification record);

    UserIdentification selectByPrimaryKey(Long userId);

    int updateByPrimaryKeySelective(UserIdentification record);

    int updateByPrimaryKey(UserIdentification record);

    int selectTotal(@Param("record") UserIdentification record);

    List<UserIdentification> selectList(@Param("record") UserIdentification record, @Param("order") Order order, @Param("offset") int offset, @Param("count") int count);
}