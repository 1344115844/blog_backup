package yiyou.tt.commision.modules.identify.service;

import com.lingz.component.db.Order;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.util.Assert;
import org.springframework.util.CollectionUtils;
import yiyou.tt.commision.modules.identify.mapper.UserIdentificationMapper;
import yiyou.tt.commision.modules.identify.model.UserIdentification;

@Service
public class UserIdentificationService {
    @Autowired
    private UserIdentificationMapper userIdentificationMapper;

    public int deleteByPrimaryKey(Long userId) {
        Assert.notNull(userId,"userId不能为空");
        return userIdentificationMapper.deleteByPrimaryKey(userId);
    }

    public int insert(UserIdentification record) {
        Assert.notNull(record, "查询对象不能为空");
        return userIdentificationMapper.insert(record);
    }

    public int insertSelective(UserIdentification record) {
        Assert.notNull(record, "查询对象不能为空");
        return userIdentificationMapper.insertSelective(record);
    }

    public UserIdentification selectByPrimaryKey(Long userId) {
        Assert.notNull(userId, "userId不能为空");
        return userIdentificationMapper.selectByPrimaryKey(userId);
    }

    public int updateByPrimaryKeySelective(UserIdentification record) {
        Assert.notNull(record, "查询对象不能为空");
        return userIdentificationMapper.updateByPrimaryKeySelective(record);
    }

    public int selectTotal(UserIdentification record) {
        Assert.notNull(record, "查询对象不能为空");
        return userIdentificationMapper.selectTotal(record);
    }

    public List<UserIdentification> selectList(UserIdentification record, Order order, int offset, int count) {
        Assert.notNull(record, "查询对象不能为空");
        return userIdentificationMapper.selectList(record, order, offset, count);
    }

    public UserIdentification selectOne(UserIdentification record, Order order) {
        Assert.notNull(record, "查询对象不能为空");
        List<UserIdentification> list = selectList(record, order, 0, 1);
        return CollectionUtils.isEmpty(list) ? null : list.get(0);
    }
}