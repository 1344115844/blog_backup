package yiyou.tt.commision.modules.identify.controller;

import com.lingz.component.datatable.BootstrapTable;
import java.util.List;
import java.util.Map;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.util.Assert;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import yiyou.tt.commision.modules.identify.model.UserIdentification;
import yiyou.tt.commision.modules.identify.service.UserIdentificationService;

@Controller
@RequestMapping("userIdentification")
public class UserIdentificationController {
    @Autowired
    private UserIdentificationService userIdentificationService;

    @RequestMapping("/index")
    public String index() {
        return "userIdentification/index";
    }

    @RequestMapping("/getList")
    @ResponseBody
    public BootstrapTable getList(UserIdentification userIdentification, Order order, int offset, int limit) {
        int total = userIdentificationService.selectTotal(userIdentification);
        List<UserIdentification> list = null;
        if(total > 0) {
            list = userIdentificationService.selectList(userIdentification, order, offset, limit);
        }
        
        return ResponseHelper.BootstrapTable(total, list);
    }

    @RequestMapping("/update")
    @ResponseBody
    public Map update(UserIdentification userIdentification) {
        
        if (userIdentificationService.updateByPrimaryKeySelective(userIdentification) < 1 ) {
            return ResponseHelper.buildErrorResult("更新失败");
        }
        
        return ResponseHelper.buildSuccessResult();
    }

    @RequestMapping("/save")
    @ResponseBody
    public Map save(UserIdentification userIdentification) {
        if (userIdentificationService.insertSelective(userIdentification) < 1 ) {
            return ResponseHelper.buildErrorResult(" 添加失败 ");
        }
        
        return ResponseHelper.buildSuccessResult();
    }

    @RequestMapping("/detail")
    public String detail(Long userId, Model model) {
        Assert.notNull(userId, "userId不能为空");
        
        UserIdentification userIdentification = userIdentificationService.selectByPrimaryKey(userId);
        
        Assert.notNull(userIdentification, "对象不存在");
        
        model.addAttribute("userIdentification", userIdentification);
        return "userIdentification/detail";
    }

    @RequestMapping("/delete")
    @ResponseBody
    public Map delete(Long userId) {
        Assert.notNull(userId, "userId不能为空");
        
        if (userIdentificationService.deleteByPrimaryKey(userId) < 1) {
            return ResponseHelper.buildErrorResult("删除失败");
        }
        
        return ResponseHelper.buildSuccessResult("删除成功");
    }
}