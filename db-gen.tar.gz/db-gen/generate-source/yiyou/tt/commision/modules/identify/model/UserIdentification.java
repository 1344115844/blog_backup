package yiyou.tt.commision.modules.identify.model;

import java.io.Serializable;
import java.util.Date;

public class UserIdentification implements Serializable {
    /**
     *  用户id
     */
    private Long userId;

    /**
     *  真实姓名
     */
    private String realName;

    /**
     *  身份证号码
     */
    private String identityCard;

    /**
     *  银行id,对应bank_info.bank_id
     */
    private Integer bankId;

    /**
     *  银行卡
     */
    private String bankCard;

    /**
     *  身份证照片(手持正面)
     */
    private String identityCardImgFront;

    /**
     *  身份证照片(手持反面)
     */
    private String identityCardImgVerso;

    /**
     *  身份证照片(正面)
     */
    private String identityCardFront;

    /**
     *  身份证照片(反面)
     */
    private String identityCardVerso;

    /**
     *  银行卡开户省份
     */
    private String bankProvince;

    /**
     *  银行卡开户城市
     */
    private String bankCity;

    /**
     *  银行卡开户分/支行
     */
    private String openingBank;

    /**
     *  手机号码
     */
    private String phone;

    /**
     *  提现的密码
     */
    private String password;

    /**
     *  支付宝帐号
     */
    private String alipay;

    /**
     *  审核状态(0,待审核;1,审核通过;2,审核未通过)
     */
    private Byte status;

    /**
     *  身份证有效期("yyyy-MM-dd")
     */
    private String expireDate;

    /**
     *  修改时间
     */
    private Date modifyTime;

    /**
     *  创建时间
     */
    private Date createTime;

    /**
     *  是否被逻辑删除(1,已经删除;0,未删除)
     */
    private Boolean deleted;

    /**
     *  打款账户所在城市。1：广州；2：海南
     */
    private Integer payCity;

    /**
     *  实名类型0:人工，1：faceid
     */
    private Integer identifiedType;

    private static final long serialVersionUID = 1L;

    public Long getUserId() {
        return userId;
    }

    public void setUserId(Long userId) {
        this.userId = userId;
    }

    public String getRealName() {
        return realName;
    }

    public void setRealName(String realName) {
        this.realName = realName;
    }

    public String getIdentityCard() {
        return identityCard;
    }

    public void setIdentityCard(String identityCard) {
        this.identityCard = identityCard;
    }

    public Integer getBankId() {
        return bankId;
    }

    public void setBankId(Integer bankId) {
        this.bankId = bankId;
    }

    public String getBankCard() {
        return bankCard;
    }

    public void setBankCard(String bankCard) {
        this.bankCard = bankCard;
    }

    public String getIdentityCardImgFront() {
        return identityCardImgFront;
    }

    public void setIdentityCardImgFront(String identityCardImgFront) {
        this.identityCardImgFront = identityCardImgFront;
    }

    public String getIdentityCardImgVerso() {
        return identityCardImgVerso;
    }

    public void setIdentityCardImgVerso(String identityCardImgVerso) {
        this.identityCardImgVerso = identityCardImgVerso;
    }

    public String getIdentityCardFront() {
        return identityCardFront;
    }

    public void setIdentityCardFront(String identityCardFront) {
        this.identityCardFront = identityCardFront;
    }

    public String getIdentityCardVerso() {
        return identityCardVerso;
    }

    public void setIdentityCardVerso(String identityCardVerso) {
        this.identityCardVerso = identityCardVerso;
    }

    public String getBankProvince() {
        return bankProvince;
    }

    public void setBankProvince(String bankProvince) {
        this.bankProvince = bankProvince;
    }

    public String getBankCity() {
        return bankCity;
    }

    public void setBankCity(String bankCity) {
        this.bankCity = bankCity;
    }

    public String getOpeningBank() {
        return openingBank;
    }

    public void setOpeningBank(String openingBank) {
        this.openingBank = openingBank;
    }

    public String getPhone() {
        return phone;
    }

    public void setPhone(String phone) {
        this.phone = phone;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public String getAlipay() {
        return alipay;
    }

    public void setAlipay(String alipay) {
        this.alipay = alipay;
    }

    public Byte getStatus() {
        return status;
    }

    public void setStatus(Byte status) {
        this.status = status;
    }

    public String getExpireDate() {
        return expireDate;
    }

    public void setExpireDate(String expireDate) {
        this.expireDate = expireDate;
    }

    public Date getModifyTime() {
        return modifyTime;
    }

    public void setModifyTime(Date modifyTime) {
        this.modifyTime = modifyTime;
    }

    public Date getCreateTime() {
        return createTime;
    }

    public void setCreateTime(Date createTime) {
        this.createTime = createTime;
    }

    public Boolean getDeleted() {
        return deleted;
    }

    public void setDeleted(Boolean deleted) {
        this.deleted = deleted;
    }

    public Integer getPayCity() {
        return payCity;
    }

    public void setPayCity(Integer payCity) {
        this.payCity = payCity;
    }

    public Integer getIdentifiedType() {
        return identifiedType;
    }

    public void setIdentifiedType(Integer identifiedType) {
        this.identifiedType = identifiedType;
    }
}